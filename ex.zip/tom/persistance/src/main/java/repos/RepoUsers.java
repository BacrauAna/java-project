package repos;

import domain.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class RepoUsers {
    public SessionFactory sessionFactory;

    public RepoUsers() {

    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
//    public void setSessionFactory(SessionFactory sessionFactory) {
//        this.sessionFactory = sessionFactory;
//    }

    public RepoUsers(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public User findOne(String userName, String pass){
        User user=null;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            user = session.createQuery("from domain.User as us where us.name = :n and us.password= :p",User.class)
                    .setString("n",userName)
                    .setString("p",pass)
                    .setMaxResults(1)
                    .uniqueResult();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return user;
    }
    public User findOne2(Long id){
        User user=null;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            user = session.createQuery("from domain.User as us where us.id = :n",User.class)
                    .setLong("n",id)
                    .setMaxResults(1)
                    .uniqueResult();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return user;
    }
}
