package repos;

import domain.Answer;
import domain.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.stream.Collectors;

@Repository
public class RepoAnswers {
    SessionFactory sessionFactory;

    public RepoAnswers() {

    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public void addAnswer(Answer answer){
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            session.saveOrUpdate(answer);
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    public int getPoints(Long userId, Long contestId){
        int points=0;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            session.createQuery("from domain.Answer as us where us.contest.id = :n and us.user.id= :p", Answer.class );
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return points;
    }
    public List<User> getClasament(Long contestId){
        Map<Long,User> map=new HashMap<>();
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            List<Answer> answerList = session.createQuery("from domain.Answer as us where us.contest.id = :n", Answer.class ).list();
            tran.commit();
            answerList.forEach(x->{
                map.put(x.id,x.user);
            });
            answerList.forEach(x->{
                int points = x.points;
                int lastPoints=map.get(x.user.getId()).getPoints();
                map.get(x.user.getId()).setPoints(points+lastPoints);
            });
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return map.values().stream().collect(Collectors.toList());
    }
}
