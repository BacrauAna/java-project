package repos;

import domain.Contest;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class RepoContest {
    public SessionFactory sessionFactory;

    public RepoContest() {

    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }
    public Long addContest(Contest contest){
        Long id=-1l;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            session.save(contest);
            id=contest.getId();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return id;
    }
    public void updateContest(Contest contest){
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            session.update(contest);
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
    }
    public Contest findContest(Long id){
        Contest contest=null;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            contest = session.createQuery("from domain.Contest as c where c.id = :id ",Contest.class)
                    .setLong("id",id)
                    .setMaxResults(1)
                    .uniqueResult();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return contest;
    }
}
