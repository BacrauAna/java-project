package controllers;

import domain.User;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import services.IService;

public class logController {
    Controller mainController;
    transient IService service;
    transient User currentUser;
    transient Scene scene;
    Stage primaryStage;

    @FXML
    transient TextField userTextField;
    @FXML
    transient TextField passTextField;


    public logController() {
    }

    public void setService(IService service) {
        this.service = service;
    }

    public void logIn(MouseEvent event) {
        try {
            String name = userTextField.getText();
            String pass = passTextField.getText();
            currentUser = service.logIn(name, pass, mainController);
            userTextField.clear();
            passTextField.clear();
            userTextField.getScene().getWindow().hide();

//            FXMLLoader cloader = new FXMLLoader(getClass().getClassLoader().getResource("mainView.fxml"));
//            Parent mainRoot = cloader.load();
//            Controller mainCtrl = cloader.getController();
//            mainCtrl.setService(service);
//            mainCtrl.setLogController(this);
//
//            this.setMainController(mainCtrl);
//            stage.setTitle("Contest Window for " + currentUser.getName());
//            stage.setScene(new Scene(mainRoot));
//            stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
//                @Override
//                public void handle(WindowEvent event) {
//                    chatCtrl.logOut();
//                    System.exit(0);
//                }
//            });
            mainController.setUser(currentUser);
            primaryStage = new Stage();

            primaryStage.setTitle("Children Contest");
            primaryStage.setScene(this.scene);
            primaryStage.show();;

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Children Contest");
            alert.setHeaderText("Authentication failure");
            alert.setContentText("Wrong username or password");
            alert.showAndWait();
            System.out.println(e.getMessage()+"\n") ;e.printStackTrace();
        }
    }

    public void handleLogOut() {
        primaryStage.close();
        System.exit(0);

    }
    public void setSage(Scene scene){
        this.scene=scene;
    }

//    public void pressCancel(ActionEvent actionEvent) {
//        System.exit(0);
//    }


    public void setMainController(Controller chatController) {
        this.mainController = chatController;
    }
}
