package controllers;

import domain.Answer;
import domain.ContestDto;
import domain.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import services.IObserver;
import services.IService;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class Controller extends UnicastRemoteObject implements IObserver, Serializable{
    transient IService service;
    int points = 0;
    User currentUser;
    transient logController myLogController;
    transient Scene myScene;
    transient String currentLetter;

    @FXML transient Button startBtn;
    @FXML transient TextField letterTF;
    @FXML transient  TextField countryTF;
    @FXML transient  TextField cityTF;
    @FXML transient  Button sendBtn;
    @FXML transient  TextField pointsTF;
    @FXML transient TableView<User> table;

    public Controller() throws RemoteException {

    }

    public void initialize(){
//         startBtn.setDisable(true);
         letterTF.setEditable(false);
    }
    public void handleCanStart(){
        try {
            startBtn.setDisable(false);
        }
        catch (Exception ex){
            ex.printStackTrace();
        }
    }
    @Override
    public void startGame(ContestDto contestDto) throws RemoteException {
        this.currentLetter = contestDto.letter;
        letterTF.setText(currentLetter);
    }

    public void setService(IService service){
        this.service=service;
        initialize();
    }

    public void setLogController(logController ctr) {
        myLogController = ctr;
    }
    public void setStage(Scene scene){
        this.myScene=scene;
    }
    public void setUser(User u){
        this.currentUser=u;
    }

    public void handleStartGame(MouseEvent event) {
        System.out.println("");
        this.service.getLetter();
    }

    public void handleSend(MouseEvent event) {
        Answer answer=new Answer();
        answer.user=currentUser;
        answer.country=countryTF.getText();
        answer.city=cityTF.getText();
        answer.letter=letterTF.getText();
        this.service.saveAnswer(answer);
    }
    public void receivePoints(ContestDto contestDto) {
        if (!contestDto.gameOver) {
            Integer p = contestDto.pointsMap.get(currentUser.getId());
            pointsTF.setText(p.toString());
            letterTF.setText(contestDto.letter);
            cityTF.clear();
            countryTF.clear();
        }
        else{

        }
    }

}
