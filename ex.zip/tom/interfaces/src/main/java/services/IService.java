package services;

import domain.Answer;
import domain.User;

import java.io.Serializable;

public interface IService extends Serializable {
    public User logIn(String user, String pass, IObserver client) throws Exception;
    void getLetter();
    void saveAnswer(Answer answer);
}
