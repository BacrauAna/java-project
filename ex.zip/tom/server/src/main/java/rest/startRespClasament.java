package rest;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import repos.RepoAnswers;
import repos.RepoContest;
import repos.RepoUsers;


@ComponentScan("repos")
@ComponentScan("services")
@SpringBootApplication

public class startRespClasament {
    static SessionFactory sessionFactory;
    static RepoContest repoContest;
    static RepoAnswers repoAnswers;

    public static void initialize(){
        Configuration configuration = new Configuration();
        configuration.configure();
        ServiceRegistry serviceRegistry =new StandardServiceRegistryBuilder().applySettings(
                configuration.getProperties()).build();
        sessionFactory = configuration.buildSessionFactory(serviceRegistry);

    }

    public static void main(String[] args) {
        ApplicationContext factory=new ClassPathXmlApplicationContext("classpath:springProp.xml");
        RepoUsers repoUsers=(RepoUsers) factory.getBean("repoUsers");
        repoContest=(RepoContest) factory.getBean("repoContest");
        repoAnswers=(RepoAnswers) factory.getBean("repoAns");
        initialize();
        repoContest.setSessionFactory(sessionFactory);
        repoAnswers.setSessionFactory(sessionFactory);
        SpringApplication.run(startRespClasament.class, args);
    }
    @Bean
    public RepoAnswers studentMapper() {
        return repoAnswers;
    }
    @Bean
    public RepoContest repoContest() {
        return repoContest;
    }
}
