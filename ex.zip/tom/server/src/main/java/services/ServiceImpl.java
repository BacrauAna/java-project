package services;

import domain.Answer;
import domain.Contest;
import domain.ContestDto;
import domain.User;
import repos.RepoAnswers;
import repos.RepoContest;
import repos.RepoUsers;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class ServiceImpl implements IService {
    RepoUsers repoUsers;
    RepoContest repoContest;
    RepoAnswers repoAnswers;
    Map<String, IObserver> loggedIn;
    ArrayList<Answer> answers=new ArrayList<>();
    Map<User, Integer> pointsMaop = new HashMap<>();
    String[] letterList={"A","B","C"};
    ContestDto currentContest;
    int noPlayersNeeded=1;
    int noAnswers=0;
    int noRounds=0;

    public ServiceImpl(RepoUsers repoUsers,RepoContest repoContest, RepoAnswers repoAnswers) {
        this.repoUsers = repoUsers;
        this.repoContest = repoContest;
        this.repoAnswers=repoAnswers;
        loggedIn = new HashMap<>();

    }
    public synchronized User logIn(String user,String pass, IObserver client) throws Exception {
//        if (this.loggedIn.get(user.getId())!=null){
//            throw new Exception("Clientul este deja conectat la server");
//        }
        User u=this.repoUsers.findOne(user,pass);
        if (u==null)
            throw new Exception("User not found");
        this.loggedIn.put(user,client);
        pointsMaop.put(u,0);
        if (this.loggedIn.size()==this.noPlayersNeeded)
            emitCanStart();
        return u;
    }
    public void emitCanStart() {
        ExecutorService executorService= Executors.newFixedThreadPool(5);
        for (IObserver client : this.loggedIn.values()){
            executorService.execute(()-> {
                try {
                    client.handleCanStart();
                }catch (RemoteException ex){
                    ex.printStackTrace();
                }
            });
        }
    }
    public void emitStartGame(ContestDto contestDto){
        ExecutorService executorService= Executors.newFixedThreadPool(5);
        for (IObserver client : this.loggedIn.values()){
            executorService.execute(()-> {
                try {
                    client.startGame(contestDto);
                }catch (RemoteException ex){
                    ex.printStackTrace();
                }
            });
        }
    }
    public void emitCurrentPoints() {
        this.currentContest.letter=letterList[0];
        this.currentContest.pointsMap=this.pointsMaop;
        if (this.noRounds==3)
            currentContest.gameOver=true;
        else
            currentContest.gameOver=false;
        ExecutorService executorService= Executors.newFixedThreadPool(5);
        for (IObserver client : this.loggedIn.values()){
            executorService.execute(()-> {
                try {
                    client.receivePoints(this.currentContest);
                }catch (RemoteException ex){
                    ex.printStackTrace();
                }
            });
        }
    }
    public void getLetter(){
        Contest contest=new Contest();
        //contest.setUsers(answers.stream().map(x->x.user).collect(Collectors.toList()));
        Long id = repoContest.addContest(contest);
        ContestDto dto=new ContestDto(id,letterList[1]);
        currentContest = dto;
        emitStartGame(dto);
    }
    public void sendPoints(){
        List<User> userIds = new ArrayList<>(this.pointsMaop.keySet());
        String letter = this.answers.get(0).letter;
        User u1=userIds.get(0);
        String city1 = this.answers.stream().filter(x-> x.user.id.equals(u1.id)).findFirst().get().city;
        String country1 = this.answers.stream().filter(x-> x.user.id.equals(u1.id)).findFirst().get().country;
        if (city1.toUpperCase().startsWith(letter)) {
            int noPoints=pointsMaop.get(u1);
            this.answers.stream().filter(x->x.user.id.equals(u1.id)).findFirst().get().points+=10;
            pointsMaop.put(u1,noPoints+10);

        }
        if (country1.toUpperCase().startsWith(letter)) {
            int noPoints=pointsMaop.get(u1.getId());
            pointsMaop.put(u1,noPoints+10);
            this.answers.stream().filter(x->x.user.id.equals(u1.id)).findFirst().get().points+=10;
        }
        saveAnswers();
        emitCurrentPoints();
    }
    public void saveAnswers(){
        Contest c =repoContest.findContest(this.currentContest.contestId);
        for (Answer ans : this.answers ) {
            ans.contest=c;
            repoAnswers.addAnswer(ans);
        }
        this.noAnswers=0;
        this.answers.clear();
        this.noRounds+=1;
    }
    public void saveAnswer(Answer answer){
        this.answers.add(answer);
        if (answers.size()==noPlayersNeeded) {
            sendPoints();
        }
    }

}
