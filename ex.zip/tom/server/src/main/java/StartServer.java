import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import repos.RepoAnswers;
import repos.RepoContest;
import repos.RepoUsers;
import services.IService;
import services.ServiceImpl;

public class StartServer {
    static SessionFactory sessionFactory;

    public static void initialize(){
        final StandardServiceRegistry registry=new StandardServiceRegistryBuilder().configure().build();
        try{
            sessionFactory=new MetadataSources(registry).buildMetadata().buildSessionFactory();
//            sessionFactory = new AnnotationConfiguration()
        }catch (Exception ex){
            StandardServiceRegistryBuilder.destroy(registry);
        }
    }
    public static void main(String[] args){

        ApplicationContext factory=new ClassPathXmlApplicationContext("classpath:springProp.xml");
        RepoUsers repoUsers=(RepoUsers) factory.getBean("repoUsers");
        RepoContest repoContest=(RepoContest) factory.getBean("repoContest");
        RepoAnswers repoAnswers=(RepoAnswers) factory.getBean("repoAns");
//        IService service=new ServiceImpl(repoUsers);

//        SessionFactory sessionFactory = (SessionFactory) factory.getBean("sessionFactory");
        initialize();
        repoUsers.setSessionFactory(sessionFactory);
        repoContest.setSessionFactory(sessionFactory);
        repoAnswers.setSessionFactory(sessionFactory);
        System.out.println("server open");
    }

}