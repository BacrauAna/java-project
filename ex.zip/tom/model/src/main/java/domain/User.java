package domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "users")
public class User implements Serializable {
    @Id
    @GeneratedValue
    public Long id;
    @Column(name = "name")
    public String name;
    @Column(name = "password")
    public String password;

    @OneToMany(mappedBy = "user")
    public List<Answer> answerList=new ArrayList<>();

    int points=0;

    @ManyToMany
    @JoinTable(
            name = "participants",
            joinColumns = { @JoinColumn (name = "userId") },
            inverseJoinColumns = { @JoinColumn (name = "contestId") })
    public List<Contest> contests=new ArrayList<>();

    public User() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return getId().equals(user.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }

    public void setAnswerList(List<Answer> answerList) {
        this.answerList = answerList;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public void setContests(List<Contest> contests) {
        this.contests = contests;
    }

    public List<Answer> getAnswerList() {
        return answerList;
    }

    public int getPoints() {
        return points;
    }

    public List<Contest> getContests() {
        return contests;
    }

    public User(Long id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
}
