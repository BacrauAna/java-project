package domain;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ContestDto implements Serializable {
    public Long contestId;
    public String letter;
    public Map<User, Integer> pointsMap;
    public boolean gameOver;

    public ContestDto(Long contestId, String letter) {
        this.contestId = contestId;
        this.letter = letter;
        pointsMap = new HashMap<>();
    }
}
