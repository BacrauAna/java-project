package domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="contest")
public class Contest implements Serializable {
    @Id
    @GeneratedValue
    public Long id;

    @ManyToMany
    @JoinTable(
            name = "participants",
            joinColumns = { @JoinColumn (name = "contestId") },
            inverseJoinColumns = { @JoinColumn (name = "userId") })
    public List<User> users;

    @OneToMany
    @JoinColumn (name = "contestId")
    public List<Answer> answers;

    public Contest(Long id, List<User> users) {
        this.id = id;
        this.users = users;
    }

    public Contest() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public Long getId() {
        return id;
    }

    public List<User> getUsers() {
        return users;
    }
}
