package domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "answers")
public class Answer implements Serializable {
    @Id
    @GeneratedValue
    public Long id;

    @ManyToOne
    @JoinColumn(name="contestId")
    public Contest contest;

    @ManyToOne
    @JoinColumn(name="userId")
    public User user;

    @Column(name = "letter")
    public String letter;
    @Column(name = "country")
    public String country;
    @Column(name = "city")
    public String city;

    @Column(name = "points")
    public int points;

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public Answer() {
    }

    public Answer(Long id,User user, Contest contest, String letter, String country, String city) {
        this.id=id;
        this.letter = letter;
        this.country = country;
        this.city = city;
        this.user = user;
        this.contest = contest;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setContest(Contest contest) {
        this.contest = contest;
    }

    public User getUser() {
        return user;
    }

    public Contest getContest() {
        return contest;
    }

    public void setLetter(String letter) {
        this.letter = letter;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLetter() {
        return letter;
    }

    public String getCountry() {
        return country;
    }

    public String getCity() {
        return city;
    }
}
