import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StartServer {
        static SessionFactory sessionFactory;

//    public static void initialize(){
//        final StandardServiceRegistry registry=new StandardServiceRegistryBuilder().configure().build();
//        try{
//            sessionFactory=new MetadataSources(registry).buildMetadata().buildSessionFactory();
//        }catch (Exception ex){
//            StandardServiceRegistryBuilder.destroy(registry);
//        }
//    }
    public static void main(String[] args){
//        System.setProperty("java.rmi.server.hostname","127.0.0.1");

        ApplicationContext factory=new ClassPathXmlApplicationContext("classpath:spring.xml");
//        RepoJucatori repoJuc=(RepoJucatori) factory.getBean("repoJuc");
//        RepoJoc repoJoc=(RepoJoc) factory.getBean("repoContest");
//        IService service=new ServiceImpl(repoUsers);

//        SessionFactory sessionFactory = (SessionFactory) factory.getBean("sessionFactory");
//        initialize();
//        repoUsers.setSessionFactory(sessionFactory);
//        repoContest.setSessionFactory(sessionFactory);
//        repoAnswers.setSessionFactory(sessionFactory);
        System.out.println("server open");
    }

}