package rest.pac;

import model.Player;
import model.RestDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import repos.RepoPlayers;

@CrossOrigin
@RestController
@RequestMapping("/joc")
public class RestController1 {

    public RepoPlayers repoPlayers=new RepoPlayers();

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public String getHello(){
        return "hello";
    }

    @RequestMapping(value = "/{idJoc}/{nume}", method = RequestMethod.GET)
    public ResponseEntity<?> getById (@PathVariable int idJoc, @PathVariable String nume){
//        ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");
//        SessionFactory sessionFactory=(SessionFactory) factory.getBean("sessionfactory");
//        repoPlayers.setSessionFactory(sessionFactory);
        RestDto player=repoPlayers.getForRest(idJoc,nume);
        if (player==null)
            return new ResponseEntity<String>("User not found", HttpStatus.NOT_FOUND);
        else {
            return new ResponseEntity<RestDto>(player, HttpStatus.OK);
        }
    }
}

