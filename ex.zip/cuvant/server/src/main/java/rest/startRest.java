package rest;

        import org.springframework.boot.SpringApplication;
        import org.springframework.boot.autoconfigure.SpringBootApplication;
        import org.springframework.context.annotation.ComponentScan;

@ComponentScan("repos")
@ComponentScan("rest.pac")
@SpringBootApplication
public class startRest{
//  ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");

    public static void main(String[] args) {
//        ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");

        SpringApplication.run(startRest.class, args);
    }

}
