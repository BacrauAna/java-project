package services;

import interfaces.IObserver;
import interfaces.IService;
import model.Game;
import model.Player;
import model.User;
import model.dto;
import repos.RepoGames;
import repos.RepoPlayers;
import repos.RepoUsers;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class ServiceImpl implements IService {
    public RepoUsers repoUsers;
    public RepoPlayers repoPlayers;
    public RepoGames repoGames;
    public int current=0;
    public String currentName="";
    public Game currentGame;
    public Map<String,IObserver> nameMap = new ConcurrentHashMap<>();
    public Map<Player,IObserver> playerMap = new ConcurrentHashMap<>();
    public ArrayList<dto> observers= new ArrayList();

    public ServiceImpl(RepoUsers repoUsers,RepoPlayers repoPlayers,RepoGames repoGames) {
        this.repoUsers = repoUsers;
        this.repoPlayers=repoPlayers;
        this.repoGames=repoGames;
    }

    @Override
    public User logIn(String name, String pass, IObserver obs) {
        User user = repoUsers.findOne(name,pass);
        nameMap.put(user.getNume(),obs);
        return user;
    }

    @Override
    public void startGame() {
        Game game = new Game();
        nameMap.forEach((x,y)->{
            Player player=new Player();
            player.game=game;
            player.name=x;
            player.user=repoUsers.findOne(x);
            player.letters="";
            player.ponts=0;
            player.word="";
            game.players.add(player);
            observers.add(new dto(y,player));
            playerMap.put(player,y);
        });
       currentGame=game;
       sendPlayers();
    }
    public void sendPlayers() {
        currentGame.players=observers.stream().map(x->{return x.getPlayer();}).collect(Collectors.toList());
        repoGames.saveGame(currentGame);
        currentName=observers.get(current).getPlayer().name;
        List<Player> list=new ArrayList<>();
        this.observers.forEach(x->{
            list.add(x.getPlayer());
        });
        ExecutorService executorService= Executors.newFixedThreadPool(10);
        playerMap.values().forEach(x -> {
            executorService.execute(()-> {
                try {
                    x.allPlayers(list,currentName);
                }catch (RemoteException ex){
                    ex.printStackTrace();
                }
            });
        });
    }

    public void sendWord(Player player){
        Player player1 = observers.stream().filter(x->x.getPlayer().name.equals(player.name)).findFirst().get().getPlayer();
        player1.setWord(player.word);
        if (observers.stream().noneMatch(x -> x.getPlayer().word.equals(""))) {
            this.currentName=observers.get(this.current).getPlayer().name;
            sendPlayers();
        }
    }
    public void sendLetter(Player sendingplayer,Player wordPlayer){
        if (wordPlayer==null)
            return;
        char c=sendingplayer.letters.charAt(sendingplayer.letters.length()-1);
        if (wordPlayer.word.indexOf(c)!=-1){
            String trans=wordPlayer.trans;
            String newTrans="";
            String cuv=wordPlayer.word;
            for (int i=0; i<cuv.length(); i++){
                if (cuv.charAt(i)==c)
                    newTrans+=c;
                else
                    newTrans+=trans.charAt(i);
            }
            wordPlayer.trans=newTrans;
            sendingplayer.ponts+=1;
            String finalNewTrans = newTrans;
            observers.forEach(x->{
                if (x.getPlayer().name.equals(sendingplayer.name)) {
                    x.getPlayer().ponts = sendingplayer.ponts;
                    x.getPlayer().letters=sendingplayer.letters;
                }
                if (x.getPlayer().name.equals(wordPlayer.name))
                    x.getPlayer().setTrans(finalNewTrans);
            });
        }
        this.current=(this.current+1)%this.observers.size();
        this.sendPlayers();

    }

    @Override
    public void logOut(String name) {
        this.nameMap.remove(name);
        Player player = this.playerMap.keySet().stream().filter(x-> x.user.getNume().equals(name)).findFirst().get();
        this.playerMap.remove(player);
    }
}
