package model;

import java.io.Serializable;

public class RestDto implements Serializable {
    String name;
    int jocId;
    String litere;
    int puncte;

    public RestDto(String name, int jocId, String litere, int puncte) {
        this.name = name;
        this.jocId = jocId;
        this.litere = litere;
        this.puncte = puncte;
    }

    public RestDto() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setJocId(int jocId) {
        this.jocId = jocId;
    }

    public void setLitere(String litere) {
        this.litere = litere;
    }

    public void setPuncte(int puncte) {
        this.puncte = puncte;
    }

    public String getName() {
        return name;
    }

    public int getJocId() {
        return jocId;
    }

    public String getLitere() {
        return litere;
    }

    public int getPuncte() {
        return puncte;
    }
}
