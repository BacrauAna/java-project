package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "users")
public class User implements Serializable {
    @Id
    private String name;

    @Column(name = "pass")
    private String pass;

    public User() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(name, user.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

    public User(String nume, String pass) {
        this.name = nume;
        this.pass = pass;
    }

    public String getNume() {
        return name;
    }

    public String getPass() {
        return pass;
    }

    public void setNume(String nume) {
        this.name = nume;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
