package model;

import interfaces.IObserver;

public class dto {
    IObserver client;

    Player player;

    public dto(IObserver client, Player player) {
        this.client = client;
        this.player = player;
    }

    public IObserver getClient() {
        return client;
    }

    public Player getPlayer() {
        return player;
    }
}
