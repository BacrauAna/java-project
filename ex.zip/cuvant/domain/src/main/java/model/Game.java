package model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "games")
public class Game implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "gameId")
    public int gameId;

    @OneToMany(mappedBy = "game")
    public List<Player> players;

    public Game() {
        players=new ArrayList<>();
    }

    public Game(int gameId, ArrayList<Player> players) {
        this.gameId = gameId;
        this.players = players;
    }

    public void setGameId(int gameId) {
        this.gameId = gameId;
    }

    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    public int getGameId() {
        return gameId;
    }

    public List<Player> getPlayers() {
        return players;
    }
}
