package model;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

@Entity
@Table(name = "players")
public class Player implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    int id;

    @ManyToOne
    @JoinColumn(name = "userId")
    public User user;
    public String name;

    @ManyToOne
    @JoinColumn(name = "gameId")
    public Game game;

    @Column(name = "word")
    public String word;
    @Column(name = "points")
    public int ponts;
    @Column(name = "letters")
    public String letters;
    @Column(name = "trans")
    public String trans;

    public Player() {
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    static String cons="bcdfghjklmnpqrstvwxyz";
    static String voc="aeiou";
    public Player(User u, Game game, String word, int ponts, String letters) {
        this.user = u;
        this.name=u.getNume();
        this.game = game;
        this.word = word;
        this.trans="";
        for (int i=0; i<word.length(); i++){
            if (cons.indexOf(word.charAt(i))==-1)
                this.trans+="C";
            else
                this.trans+="V";
        }
        this.ponts = ponts;
        this.letters = letters;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Player player = (Player) o;
        return name.equals(player.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public void setWord(String word) {
        this.word = word;
        this.trans="";
        for (int i=0; i<word.length(); i++){
            if (cons.indexOf(word.charAt(i))!=-1)
                this.trans+="C";
            else
                this.trans+="V";
        }
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTrans() {
        return trans;
    }

    public void setTrans(String trans) {
        this.trans = trans;
    }

    public void setPonts(int ponts) {
        this.ponts = ponts;
    }

    public void setLetters(String letters) {
        this.letters = letters;
    }

    public User getUser() {
        return user;
    }

    public Game getGame() {
        return game;
    }

    public String getWord() {
        return word;
    }

    public int getPonts() {
        return ponts;
    }

    public String getLetters() {
        return letters;
    }
}
