package interfaces;

import model.Player;
import model.User;

import java.io.Serializable;

public interface IService extends Serializable {
    User logIn(String name, String pass, IObserver obs);
    void startGame();
    void logOut(String name);
    void sendWord(Player player);
    void sendLetter(Player player,Player player2);
}
