package interfaces;

import model.Player;

import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Set;

public interface IObserver extends Remote, Serializable {
    void allPlayers(List<Player> players,String name) throws RemoteException;
}
