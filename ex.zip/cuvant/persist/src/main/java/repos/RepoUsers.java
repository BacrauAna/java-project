package repos;

import model.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class RepoUsers {
    private SessionFactory sessionFactory;

    public RepoUsers(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    public User findOne(String name, String pass){
        User user=null;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            user = session.createQuery("from model.User as us where us.name = :n and us.pass= :p",User.class)
                    .setString("n",name)
                    .setString("p",pass)
                    .setMaxResults(1)
                    .uniqueResult();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return user;
    }
    public User findOne(String name){
        User user=null;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            user = session.createQuery("from model.User as us where us.name = :n ",User.class)
                    .setString("n",name)
                    .setMaxResults(1)
                    .uniqueResult();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return user;
    }
}
