package repos;

import model.Game;
import model.Player;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class RepoGames {
    private SessionFactory sessionFactory;
    private RepoPlayers repoPlayers;

    public RepoGames(SessionFactory sessionFactory, RepoPlayers repoPlayers) {
        this.repoPlayers=repoPlayers;
        this.sessionFactory = sessionFactory;
    }
    public Game saveGame(Game game){
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            session.saveOrUpdate(game);
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
       for (int i=0; i<game.players.size(); i++){
           Player p=repoPlayers.saveOne(game.players.get(i));
           game.players.get(i).setId(p.getId());
       }
        return game;
    }
}
