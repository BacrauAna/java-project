package repos;

import model.Game;
import model.Player;
import model.RestDto;
import model.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

@Configuration
public class RepoPlayers {
    private SessionFactory sessionFactory;

    public RepoPlayers() {
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public RepoPlayers(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public Player saveOne(Player player){
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            session.saveOrUpdate(player);
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return player;
    }
    public RestDto getForRest(int joc, String numeJuc){
       Player player=null;
       RestDto dto=new RestDto();
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            Game game = session.createQuery("FROM Game WHERE id = :id" , Game.class)
                    .setInteger("id", joc)
                    .getSingleResult();
            for (int i=0; i<game.players.size(); i++){
                if (game.players.get(i).getName().equals(numeJuc)) {
                    dto.setJocId(game.gameId);
                    dto.setLitere(game.players.get(i).letters);
                    dto.setName(game.players.get(i).getName());
                    dto.setPuncte(game.players.get(i).getPonts());
                }

            }
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return dto;

    }
}
