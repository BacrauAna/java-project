public class StartClient {

    public static void main(String[] args) {
        MainClass.main(args);

    }
}
