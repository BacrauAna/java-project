package controllers;

import interfaces.IObserver;
import interfaces.IService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import model.Player;
import model.User;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Controller extends UnicastRemoteObject implements IObserver, Serializable {
    public transient LogInController logInController;
    public transient IService service;
    public transient Scene myScene;
    public transient User jucatorCurent;
    public transient Player player;

   transient ObservableList<Player> modelPlayes = FXCollections.observableArrayList();

    @FXML transient TextField puncteTf;
    @FXML transient TextField myJucatorTF;
    @FXML transient TableView<Player> tablePlayers;
    @FXML transient TableColumn<Player, String> nameCol;
    @FXML transient TableColumn<Player, String> wordCol;
    @FXML transient TextField myWordTF;
    @FXML transient Button letterBtn;
    @FXML transient TextField letterTF;

    @FXML transient Button startBtn;
    @FXML transient  Button sendWordBtn;

    public Controller() throws RemoteException {
    }

    public void setService(IService service) {
        this.service = service;
         tablePlayers.setItems(modelPlayes);

         nameCol.setCellValueFactory(new PropertyValueFactory<Player, String>("name"));
         wordCol.setCellValueFactory(new PropertyValueFactory<Player, String>("trans"));
        letterBtn.setDisable(true);

    }
    public void setStage(Scene sc){
        this.myScene=sc;
    }

    public void setJucatorCurent(User jucatorCurent) {
        this.jucatorCurent = jucatorCurent;
        myJucatorTF.setText(jucatorCurent.getNume());
        myJucatorTF.setEditable(false);
        puncteTf.setText(String.valueOf(0));
    }
    public void logOut(){
        service.logOut(jucatorCurent.getNume());
        logInController.primaryStage.setScene(myScene);
    }

    public void setLogInController(LogInController logInController){
        this.logInController=logInController;
    }

    public void startGame(MouseEvent event) {
        service.startGame();
    }

    public void allPlayers(List<Player> players, String name){
        Platform.runLater(()-> {
        startBtn.setDisable(true);
        this.player=players.stream().filter(x->x.name.equals(jucatorCurent.getNume())).findFirst().get();
        puncteTf.setText(String.valueOf(this.player.ponts));
            modelPlayes.clear();
            modelPlayes.setAll(players);
            if (name.equals(player.name)){
                letterBtn.setDisable(false);
            }
        });

    }

    public void sendWord(MouseEvent event) {
        player.word=myWordTF.getText();
        myWordTF.setEditable(false);
        service.sendWord(player);
    }

    public void sendletter(MouseEvent event) {
        String letter =  this.letterTF.getText().trim();
        if (letter.length()!=1)
            return;
        this.letterTF.clear();
        player.letters+=letter;
        Player player1 = tablePlayers.getSelectionModel().getSelectedItem();
        if (player1.name.equals(player.name) || player1==null)
            return;
        service.sendLetter(this.player,player1);
        letterBtn.setDisable(true);
    }
/*

    public void finalJoc(int id) {
        Platform.runLater(() -> {
                    if (id == jucatorCurent.id) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle(jucatorCurent.nume);
                        alert.setContentText("Ai Castigat");
                        alert.showAndWait();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle(jucatorCurent.nume);
                        alert.setContentText("Ai Pierdut");
                        alert.showAndWait();
                    }
                }
        );
    }

     */
}
