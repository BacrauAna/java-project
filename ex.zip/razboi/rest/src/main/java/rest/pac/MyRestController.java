package rest.pac;
import domain.Joc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import repo2.RepoJoc;
import repo2.RepoJucatori;

@CrossOrigin
@RestController
@RequestMapping("/razboi/joc")
public class MyRestController {
    @Autowired
    public RepoJucatori repoJucatori;
    @Autowired
    public RepoJoc repoContest;

    public MyRestController() {
    }

    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public String getHello(){
        return "hello";
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> getById (@PathVariable int id){
        Joc c = repoContest.findOne(id);
        if (c==null)
            return new ResponseEntity<String>("User not found",HttpStatus.NOT_FOUND);
        else {
            return new ResponseEntity<Joc>(c, HttpStatus.OK);
        }
    }
}

