package rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import repo2.RepoJoc;
import repo2.RepoJucatori;

@ComponentScan("repo2")
@ComponentScan("utils2")
@ComponentScan("rest.pac")
@SpringBootApplication
public class Start{
//    ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");

    public static void main(String[] args) {
        //ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");

        SpringApplication.run(rest.Start.class, args);
    }
//    @Bean
//    public RepoJucatori getRepoJucatori(){
//        return (RepoJucatori)factory.getBean("repoJuc");
//    }
//    @Bean
//    public RepoJoc getRepoJuc(){
//        return (RepoJoc)factory.getBean("repoContest");
//    }

}
