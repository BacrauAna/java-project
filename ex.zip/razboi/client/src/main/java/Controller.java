import domain.Carte;
import domain.Jucator;
import interfaces.IObserver;
import interfaces.IService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class Controller extends UnicastRemoteObject implements IObserver, Serializable {
    public transient LogInController logInController;
    public transient IService service;
    public transient Scene myScene;
    public transient Jucator jucatorCurent;

    transient ObservableList<Carte> modelCarti = FXCollections.observableArrayList();
    transient ObservableList<Carte> modelCartiOthers = FXCollections.observableArrayList();


    @FXML transient TextField puncteTf;
    @FXML
    transient TextField myJucatorTF;
    @FXML transient ListView<Carte> listaCarti;
    @FXML transient ListView<Carte>  cartiCeilalti;
    @FXML transient Button startBtn;
    @FXML transient  Button alegeBtn;

    public Controller() throws RemoteException {
    }

    public void setService(IService service) {
        this.service = service;
        listaCarti.setItems(modelCarti);
        cartiCeilalti.setItems(modelCartiOthers);
        alegeBtn.setDisable(true);
    }
    public void setStage(Scene sc){
        this.myScene=sc;
    }

    public void setJucatorCurent(Jucator jucatorCurent) {
        this.jucatorCurent = jucatorCurent;
        myJucatorTF.setText(jucatorCurent.nume);
        myJucatorTF.setEditable(false);
        puncteTf.setText(String.valueOf(0));
    }
    public void setLogInController(LogInController logInController){
        this.logInController=logInController;
    }

    public void startGame(MouseEvent event) {
        service.startGame();
    }
    public void primeleCarti(Jucator jucator){
        this.jucatorCurent=jucator;
        this.startBtn.setDisable(true);
        alegeBtn.setDisable(false);
        jucator.carti.forEach(x->{
            if (x.runda==0)
                modelCarti.add(x);
        });
    }

    @Override
    public void raspunsRunda(int jucId, ArrayList<Carte> lista, Integer suma) throws RemoteException {
        Platform.runLater(()-> {
            if (jucId == jucatorCurent.id) {
                Integer pct = (Integer) Integer.parseInt(puncteTf.getText()) + suma;
                puncteTf.setText(pct.toString());
                jucatorCurent.puncte=pct;
            }
            modelCartiOthers.clear();
            modelCartiOthers.setAll(lista);
            alegeBtn.setDisable(false);
        });
    }

    public void alegeCarte(MouseEvent event) {
        if (listaCarti.getSelectionModel().getSelectedItems().size()==1)
        {
            Carte carte=listaCarti.getSelectionModel().getSelectedItem();
            int runda = 4-modelCarti.size()+1;
            for (int i=0; i<jucatorCurent.carti.size(); i++){
                if(jucatorCurent.carti.get(i).getVal()==carte.getVal()) {
                    jucatorCurent.carti.get(i).setRunda(runda);
                    break;
                }
            }
            alegeBtn.setDisable(true);
            modelCarti.removeIf(x->x.runda>0);
            service.amAlesCarte(this.jucatorCurent);
        }
    }
    public void finalJoc(int id) {
        Platform.runLater(() -> {
                    if (id == jucatorCurent.id) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle(jucatorCurent.nume);
                        alert.setContentText("Ai Castigat");
                        alert.showAndWait();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle(jucatorCurent.nume);
                        alert.setContentText("Ai Pierdut");
                        alert.showAndWait();
                    }
                }
        );
    }
}
