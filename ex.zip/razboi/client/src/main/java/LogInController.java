import domain.Jucator;
import interfaces.IService;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


public class LogInController {
    IService service;
    Controller controller;
    transient Scene scene;
    Jucator jucatorCurrent;
    Stage primaryStage;
    @FXML
    transient TextField userTextField;
    @FXML
    transient TextField passTextField;

    public LogInController() {
    }

    public void setService(IService service) {
        this.service = service;
    }

    public void setSage(Scene sc){
        this.scene=sc;
    }

    public void setMainController(Controller controller){
        this.controller=controller;
    }
    public void logIn(MouseEvent event) {
        try {
            jucatorCurrent = this.service.logIn(userTextField.getText(), passTextField.getText(), controller);
            userTextField.clear();
            passTextField.clear();
            userTextField.getScene().getWindow().hide();
            controller.setJucatorCurent(jucatorCurrent);
            primaryStage = new Stage();

            primaryStage.setTitle("Children Contest");
            primaryStage.setScene(this.scene);
            primaryStage.show();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Children Contest");
            alert.setHeaderText("Authentication failure");
            alert.setContentText("Wrong username or password");
            alert.showAndWait();
            System.out.println(e.getMessage() + "\n");
            e.printStackTrace();
        }
    }
}
