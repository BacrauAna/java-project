package repo;

import domain.Carte;
import domain.Joc;
import domain.Jucator;
import utils.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class RepoJoc {
    public RepoJucatori repoJucatori;
    public ConnectionHelper connectionHelper;

    public RepoJoc(ConnectionHelper connectionHelper, RepoJucatori repoJucatori) {
        this.connectionHelper = connectionHelper;
        this.repoJucatori=repoJucatori;
    }

    public void setConnectionHelper(ConnectionHelper connectionHelper) {
        this.connectionHelper = connectionHelper;
    }

    public int createJoc(){
        int id=-1;
        try (Connection connection = connectionHelper.getConnection()) {
            try (PreparedStatement findStm = connection.prepareStatement("insert into joc values ();");) {
                findStm.executeUpdate();
            }
            try (PreparedStatement findStm = connection.prepareStatement("select max(id) from joc")) {
                try (ResultSet rss = findStm.executeQuery()) {
                    if (rss.next())
                        id = rss.getInt(1);
                }
            }
        }catch (Exception ex){
                    ex.printStackTrace();
                }
        return id;
    }
    public void saveJoc(Joc joc){

    }

    public Joc findOne(int id){
        Joc joc=null;
        ArrayList<Jucator> jucatori=new ArrayList<>();
        try (Connection connection = connectionHelper.getConnection()) {
            try (PreparedStatement findStm = connection.prepareStatement("select distinct p.idJuc from legatura p where p.idJoc=?;");) {
                findStm.setInt(1, id);
                try (ResultSet rs = findStm.executeQuery()) {
                    while (rs.next()) {
                        Jucator jucator = repoJucatori.findOne(rs.getInt("idJuc"));
                        jucatori.add(jucator);
                        try (PreparedStatement findStm2 = connection.prepareStatement("select p.nrRunda, p.valCarte from legatura p where p.idJoc=? and p.idJuc=?;");) {
                            findStm2.setInt(1, id);
                            findStm2.setInt(2,jucator.id);
                            try (ResultSet rs2 = findStm.executeQuery()) {
                                while (rs2.next()) {
                                    Carte carte = new Carte(rs2.getInt("valCarte"),rs2.getInt("nrRunda"));
                                    jucator.carti.add(carte);
                                }
                            }
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return joc;
    }
}
