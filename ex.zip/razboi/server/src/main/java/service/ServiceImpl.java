package service;

import domain.Carte;
import domain.Jucator;
import interfaces.IObserver;
import interfaces.IService;
import repo.RepoJoc;
import repo.RepoJucatori;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ServiceImpl implements IService {
    public transient RepoJucatori repoJucatori;
    public transient RepoJoc repoJoc;
    public transient Map<Jucator, IObserver> jucatoriCurenti = new HashMap<>();
    public int nrRunda=0;
    public int jocId;
    public transient ArrayList<Integer> carti = new ArrayList<>();
    public transient ArrayList<Carte> cartiAlese=new ArrayList<>();
    public int counter;

    public ServiceImpl(RepoJucatori repoJucatori, RepoJoc repoJoc) {
        this.repoJucatori = repoJucatori;
        this.repoJoc = repoJoc;
        carti.add(6);
        carti.add(7);
        carti.add(8);
        carti.add(9);
        carti.add(10);
        carti.add(11);
        carti.add(12);
        carti.add(13);
    }

    public Jucator logIn(String nume, String pass, IObserver client){
        Jucator jucator = repoJucatori.findOne(nume,pass);
        jucatoriCurenti.put(jucator,client);
        return jucator;
    }


    public void startGame(){
        this.counter=0;
        this.nrRunda=1;
        this.jocId = repoJoc.createJoc();
        jucatoriCurenti.forEach((juc,obj)->{
            juc.idJocCurent=jocId;
            juc.puncte=0;
            ArrayList<Carte> carti=new ArrayList<>();
            for (int i=0; i<4; i++){
                int index=(int)(Math.random() * (8 + 1));
                if (index>7) index=7;
                carti.add(new Carte(this.carti.get(index).toString(),this.carti.get(index),0,juc.id));
            }
            juc.carti=carti;
        });

                ExecutorService executorService= Executors.newFixedThreadPool(5);
        jucatoriCurenti.forEach((juc,obj)->{
            executorService.execute(()-> {
                try {
                    obj.primeleCarti(juc);
                }catch (RemoteException ex){
                    ex.printStackTrace();
                }
            });
        });
    }
    public void amAlesCarte(Jucator jucator){
        if (counter==0)
            this.cartiAlese=new ArrayList<>();
        counter++;
        Carte carte=jucator.carti.stream().filter(x->x.runda==this.nrRunda).findFirst().get();
        repoJucatori.addInLegatura(jucator,this.nrRunda,carte);
        cartiAlese.add(carte);
        if (counter==jucatoriCurenti.size() && this.nrRunda==4) {
            sendFinalJoc();
        }
        else
            if (counter==jucatoriCurenti.size())
                sendRaspuns();

    }

    public void sendFinalJoc(){
        int id = jucatoriCurenti.keySet().stream().sorted(new Comparator<Jucator>() {
            @Override
            public int compare(Jucator o1, Jucator o2) {
                return o1.puncte-o2.puncte;
            }
        }).findFirst().get().id;
        ExecutorService executorService= Executors.newFixedThreadPool(5);
        jucatoriCurenti.forEach((juc,obj)->{
            executorService.execute(()-> {
                try {
                    obj.finalJoc(id);
                }catch (RemoteException ex){
                    ex.printStackTrace();
                }
            });
        });
    }
    public void sendRaspuns() {
        int max = 0;
        int suma = 0;
        this.nrRunda++;
        for (Carte c : cartiAlese) {
            suma += c.val;
            if (c.val > max) max = c.val;
        }
        int finalMax = max;
        if (cartiAlese.stream().filter(x -> x.val == finalMax).count() == 1) {
            int finalMax1 = max;
            int jucatorCartigatorId = cartiAlese.stream().filter(x -> x.val == finalMax1).findFirst().get().idJucator;
            ExecutorService executorService = Executors.newFixedThreadPool(5);
            int finalSuma = suma;
            jucatoriCurenti.forEach((juc, obj) -> {
                executorService.execute(() -> {
                    try {
                        obj.raspunsRunda(jucatorCartigatorId, cartiAlese, finalSuma);
                    } catch (RemoteException ex) {
                        ex.printStackTrace();
                    }
                });

            });
        }
        counter=0;
    }

    public void setRepoJucatori(RepoJucatori repoJucatori) {
        this.repoJucatori = repoJucatori;
    }

    public void setRepoJoc(RepoJoc repoJoc) {
        this.repoJoc = repoJoc;
    }

    public RepoJucatori getRepoJucatori() {
        return repoJucatori;
    }

    public RepoJoc getRepoJoc() {
        return repoJoc;
    }


}
