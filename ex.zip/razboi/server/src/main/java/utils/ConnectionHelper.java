package utils;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class ConnectionHelper {
    private Connection connection=null;
    private Properties myProperties;

    public ConnectionHelper() {
      /*  myProperties = new Properties();
        try {
            myProperties.load(ConnectionHelper.class.getResourceAsStream("/dataBase.properties"));
            System.out.println("Server properties set. ");
            myProperties.list(System.out);
        } catch (IOException e) {
            System.err.println("Cannot find chatserver.properties " + e);
            return;
        }
    */
    }

    public ConnectionHelper(Properties prop) {
        myProperties = prop;
    }

    public Connection getConnection(){
        try {
            if (connection==null || connection.isClosed())
                connection=getNewConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    private Connection getNewConnection() {
        String user = myProperties.getProperty("user");
        String password = myProperties.getProperty("password");
        try {
            Class.forName(myProperties.getProperty("mySql.jdbcDriver"));
            connection = DriverManager.getConnection(myProperties.getProperty("mySql.url"), user, password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }


}
