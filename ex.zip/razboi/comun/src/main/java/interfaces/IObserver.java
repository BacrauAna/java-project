package interfaces;

import domain.Carte;
import domain.Dto;
import domain.Jucator;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

public interface IObserver extends Remote {
    void primeleCarti(Jucator jucator) throws RemoteException;
    void raspunsRunda(int jucId, ArrayList<Carte> lista, Integer suma) throws RemoteException;
    void finalJoc(int idCastigator) throws RemoteException;
}
