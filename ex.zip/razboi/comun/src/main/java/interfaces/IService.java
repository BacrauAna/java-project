package interfaces;

import domain.Jucator;

import java.io.Serializable;

public interface IService extends Serializable {
    Jucator logIn(String nume, String pass, IObserver client);
    void startGame();
    void amAlesCarte(Jucator jucator);
}
