package domain;

import java.io.Serializable;
import java.util.ArrayList;

public class Dto implements Serializable {
    public ArrayList<Carte> carti;
    public int jocId;

    public Dto( int jocId) {
        this.carti = new ArrayList<>();
        this.jocId = jocId;
    }
}
