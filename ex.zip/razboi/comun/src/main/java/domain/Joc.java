package domain;

import java.io.Serializable;
import java.util.ArrayList;

public class Joc implements Serializable {
    public int id;
    public ArrayList<Jucator> jucatori;
}
