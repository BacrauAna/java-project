package domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class Jucator implements Serializable {
    public int id;
    public String nume;
    public String pass;
    public ArrayList<Carte> carti = new ArrayList<>();
    public int puncte;
    public int idJocCurent;
    public int valCarteCurenta;

    public Jucator(int id, String nume, String pass) {
        this.id = id;
        this.nume = nume;
        this.pass = pass;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Jucator jucator = (Jucator) o;
        return getId() == jucator.getId();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId());
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public int getId() {
        return id;
    }

    public String getNume() {
        return nume;
    }

    public String getPass() {
        return pass;
    }
}
