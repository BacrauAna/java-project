package domain;

import java.io.Serializable;
import java.util.Objects;

public class Carte implements Serializable {
    public String id;
    public int val;
    public int runda;
    public int idJucator;
    public int puncte;


    public void setRunda(int runda) {
        this.runda = runda;
    }

    public Carte(int val, int runda) {
        this.val = val;
        this.runda = runda;
    }
    public Carte(String id,int val, int runda, int jucId) {
        this.id=id;
        this.val = val;
        this.runda = runda;
        this.idJucator = jucId;
    }

    @Override
    public String toString() {
        return "Carte{" +
                "val=" + val +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Carte carte = (Carte) o;
        return getVal() == carte.getVal();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getVal());
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setVal(int val) {
        this.val = val;
    }

    public String getId() {
        return id;
    }

    public int getVal() {
        return val;
    }

    public Carte(String id, int val) {
        this.id = id;
        this.val = val;
    }
}
