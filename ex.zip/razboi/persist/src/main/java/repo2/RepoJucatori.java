package repo2;

import domain.Carte;
import domain.Jucator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import utils2.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;


@Configuration
public class RepoJucatori {

    public ConnectionHelper connectionHelper;

    public RepoJucatori(ConnectionHelper connectionHelper) {
//        ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");
//        this.connectionHelper = (ConnectionHelper) factory.getBean("helper");
        this.connectionHelper=connectionHelper;
    }
    public void setConnectionHelper(ConnectionHelper connectionHelper) {
        this.connectionHelper = connectionHelper;
    }

    public Jucator findOne(String nume, String pas){
        Jucator jucator=null;
        try (Connection connection = connectionHelper.getConnection()) {
            try (PreparedStatement findStm = connection.prepareStatement("select p.id,p.nume,p.pass from jucatori p where p.nume=? and p.pass=?;");) {
                findStm.setString(1, nume);
                findStm.setString(2,pas);
                try (ResultSet rs = findStm.executeQuery()) {
                    if (!rs.next())
                        return jucator;
                    else
                        jucator = new Jucator(rs.getInt("id"), rs.getString("nume"), rs.getString("pass"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jucator;
    }
    public Jucator findOne(int id){
        Jucator jucator=null;
        try (Connection connection = connectionHelper.getConnection()) {
            try (PreparedStatement findStm3 = connection.prepareStatement("select p.id,p.nume,p.pass from jucatori p where p.id=?;");) {
                findStm3.setInt(1, id);
                try (ResultSet rs = findStm3.executeQuery()) {
                    if (!rs.next())
                        return jucator;
                    else
                        jucator = new Jucator(rs.getInt("id"), rs.getString("nume"), rs.getString("pass"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return jucator;
    }

    public void addInLegatura(Jucator jucator, int nrRunda, Carte carte){
        try (Connection connection = connectionHelper.getConnection()) {
            try (PreparedStatement findStm = connection.prepareStatement("insert into legatura (idJuc,idJoc,nrRunda,valCarte)" +
                    "values (?,?,?,?);");) {
                findStm.setInt(1, jucator.id);
                findStm.setInt(2,jucator.idJocCurent);
                findStm.setInt(3,nrRunda);
                findStm.setInt(4,carte.val);
                findStm.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
