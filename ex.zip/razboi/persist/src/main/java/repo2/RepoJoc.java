package repo2;

import domain.Carte;
import domain.Joc;
import domain.Jucator;
import org.graalvm.compiler.lir.CompositeValue;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import utils2.ConnectionHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

@Configuration
public class RepoJoc {
    public RepoJucatori repoJucatori;
    public ConnectionHelper connectionHelper;

    public RepoJoc( RepoJucatori repoJucatori,ConnectionHelper connectionHelper) {
//        ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");
//        this.connectionHelper = (ConnectionHelper) factory.getBean("helper");
        this.repoJucatori=repoJucatori;
        this.connectionHelper=connectionHelper;
    }

    public void setConnectionHelper(ConnectionHelper connectionHelper) {
        this.connectionHelper = connectionHelper;
    }

    public int createJoc(){
        int id=-1;
        try (Connection connection = connectionHelper.getConnection()) {
            try (PreparedStatement findStm = connection.prepareStatement("insert into joc values ();");) {
                findStm.executeUpdate();
            }
            try (PreparedStatement findStm = connection.prepareStatement("select max(id) from joc")) {
                try (ResultSet rss = findStm.executeQuery()) {
                    if (rss.next())
                        id = rss.getInt(1);
                }
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return id;
    }
    public void saveJoc(Joc joc){

    }
    public Joc findOne(int id){
        Joc joc=null;
        ArrayList<Jucator> jucatori=new ArrayList<>();
        try (Connection connection = connectionHelper.getConnection()) {
            try (PreparedStatement findStm = connection.prepareStatement("select distinct p.idJuc, j.nume, j.pass from legatura p " +
                    "inner join jucatori j on j.id=p.idJuc where p.idJoc=?;");) {
                findStm.setInt(1, id);
                try (ResultSet rs = findStm.executeQuery()) {
                    while (rs.next()) {
                        Jucator jucator = new Jucator(rs.getInt(1),rs.getString(2),rs.getString(3));
                        jucatori.add(jucator);
                    }
                }
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        jucatori.forEach(jucator->{
        try (Connection connection = connectionHelper.getConnection()) {
            try (PreparedStatement findStm2 = connection.prepareStatement("select p.nrRunda, p.valCarte from legatura p where p.idJoc=? and p.idJuc=?;");) {
                findStm2.setInt(1, id);
                findStm2.setInt(2, jucator.id);
                try (ResultSet rs2 = findStm2.executeQuery()) {
                    while (rs2.next()) {
                        Carte carte = new Carte(rs2.getInt("valCarte"), rs2.getInt("nrRunda"));
                        jucator.carti.add(carte);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }});

        joc=new Joc();
        joc.id=id;
        joc.jucatori=jucatori;
        return joc;
    }
}
