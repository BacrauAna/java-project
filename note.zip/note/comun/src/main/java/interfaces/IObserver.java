package interfaces;

import domain.User;
import domain.dto;

import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface IObserver extends Remote, Serializable {
    void allPlayers(List<dto> players) throws RemoteException;
    void endGame(List<dto> all) throws RemoteException;
 }
