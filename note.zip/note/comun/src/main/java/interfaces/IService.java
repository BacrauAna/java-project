package interfaces;

import domain.User;

import java.io.Serializable;

public interface IService extends Serializable {
    User logIn(String name, String pass, IObserver obs);
    void startGame(String name, String cuv);
    void sendLetter(String sender, String letter, String player);
    void logOut(String name);

}
