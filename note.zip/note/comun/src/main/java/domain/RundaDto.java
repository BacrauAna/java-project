package domain;

import java.io.Serializable;

public class RundaDto implements Serializable {
    public int nrRunda;
    public int puncte;
    public String prop;

    public RundaDto(int nrRunda,int puncte, String prop) {
        this.puncte = puncte;
        this.prop = prop;
        this.nrRunda=nrRunda;
    }
}
