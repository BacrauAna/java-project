package domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
@Entity
@Table(name = "joc")
public class Joc implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public int id;

    @OneToMany(mappedBy = "joc")
    public List<Jucator> jucatori=new ArrayList<>();

    public Joc() {
    }

    public Joc(int id, List<Jucator> jucatori) {
        this.id = id;
        this.jucatori = jucatori;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setJucatori(List<Jucator> jucatori) {
        this.jucatori = jucatori;
    }

    public int getId() {
        return id;
    }

    public List<Jucator> getJucatori() {
        return jucatori;
    }
}
