package domain;

import java.io.Serializable;

public class dto implements Serializable {
    public String jucName;
    public String cuv;
    public String trans;
    public int points;

    public dto(String jucName, String cuv, String trans, int p) {
        this.jucName = jucName;
        this.cuv = cuv;
        this.trans = trans;
        this.points=p;
    }

    public String getJucName() {
        return jucName;
    }

    public String getCuv() {
        return cuv;
    }

    public String getTrans() {
        return trans;
    }

    public void setJucName(String jucName) {
        this.jucName = jucName;
    }

    public int getPoints() {
        return points;
    }
}
