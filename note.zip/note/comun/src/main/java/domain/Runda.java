package domain;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "runde", catalog = "joc")
public class Runda implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    @ManyToOne
    @JoinColumn(name = "idJuc")
    public Jucator jucator;

    @Column(name = "puncte")
    public int puncte;

    @Column(name = "prop")
    public String prop;
    @Column(name = "nrRunda")
    public int nrRunda;

    public Runda() {
    }

    public Runda(int id, Jucator jucator, int puncte, String prop,int nrRunda) {
        this.jucator = jucator;
        this.puncte = puncte;
        this.id=id;
        this.prop=prop;
        this.nrRunda=nrRunda;
    }
}
