package domain;

import java.io.Serializable;

public class jucatorDto implements Serializable {
    String nume;
    String cuv;
    int pct;

    public jucatorDto(String nume, String cuv, int pct) {
        this.nume = nume;
        this.cuv = cuv;
        this.pct = pct;
    }

    public void setCuv(String cuv) {
        this.cuv = cuv;
    }

    public void setPct(int pct) {
        this.pct = pct;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getNume() {
        return nume;
    }

    public String getCuv() {
        return cuv;
    }

    public int getPct() {
        return pct;
    }
}
