package domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "jucatori")
public class Jucator implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public int id;

    @ManyToOne
    @JoinColumn(name = "jocId")
    public Joc joc;

    @ManyToOne
    @JoinColumn(name = "userName")
    public User user;

    @Column(name = "cuvant")
    public String cuv;
    @Column(name = "puncte")
    public int puncte;

    @OneToMany(mappedBy = "jucator")
    public List<Runda> runde;

    public Jucator() {
    }

    public Jucator(Joc joc, User user, String cuv, int puncte) {
        this.joc = joc;
        this.user = user;
        this.cuv = cuv;
        this.puncte = puncte;
        this.runde=new ArrayList<>();
    }

    public void setJoc(Joc joc) {
        this.joc = joc;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setCuv(String cuv) {
        this.cuv = cuv;
    }

    public void setPuncte(int puncte) {
        this.puncte = puncte;
    }

    public Joc getJoc() {
        return joc;
    }

    public User getUser() {
        return user;
    }

    public String getCuv() {
        return cuv;
    }

    public int getPuncte() {
        return puncte;
    }
}
