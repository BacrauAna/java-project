package domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "useri")
public class User  implements Serializable {
    @Id
    @Column(name = "nume")
    public String name;
    @Column(name = "pass")
    public String pass;

//    @OneToMany(mappedBy = "user")
//    public List<Jucator> jucatori;

    public User() {
    }

    public User(String nume, String pass) {
        this.name = nume;
        this.pass = pass;
    }

    public String getName() {
        return name;
    }

    public String getPass() {
        return pass;
    }

    public void setNume(String nume) {
        this.name = nume;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
