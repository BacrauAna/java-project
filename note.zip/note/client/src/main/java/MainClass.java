
import client.Controller;
import client.LogInController;
import interfaces.IService;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class MainClass extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    private Stage primaryStage;

    public void start(Stage stage) throws Exception {

        ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");
        IService service = (IService) factory.getBean("jocService");

        FXMLLoader loader = new FXMLLoader(getClass().getClassLoader().getResource("login.fxml"));
        Parent root = loader.load();
        Scene loadScene = new Scene(root);

        LogInController ctrl = loader.getController();
        ctrl.setService(service);

        FXMLLoader cloader = new FXMLLoader(getClass().getClassLoader().getResource("mainView.fxml"));
        Parent mainRoot = cloader.load();
        Scene mainScene = new Scene(mainRoot);
        Controller maincontroller = cloader.getController();
        maincontroller.setService(service);

        ctrl.setMainController(maincontroller);
        maincontroller.setLogInController(ctrl);
        maincontroller.setStage(loadScene);
        ctrl.setSage(mainScene);

        primaryStage = new Stage();

        primaryStage.setTitle("Children Contest");
        primaryStage.setScene(loadScene);
        primaryStage.show();
    }
}
