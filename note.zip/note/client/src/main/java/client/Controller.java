package client;

import domain.dto;
import interfaces.IObserver;
import interfaces.IService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import domain.User;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Controller extends UnicastRemoteObject implements IObserver, Serializable {
    public transient LogInController logInController;
    public transient IService service;
    public transient Scene myScene;
    public transient User jucatorCurent;

    transient ObservableList<dto> modelPlayes = FXCollections.observableArrayList();
    transient ObservableList<dto> modelFinal = FXCollections.observableArrayList();

    @FXML transient TextField puncteTf;
    @FXML transient TextField myJucatorTF;
    @FXML transient TableView<dto> tabelCuv;
    @FXML transient TableColumn<dto, String> nameCol;
    @FXML transient TableColumn<dto, String> cuvCol;
   @FXML transient TextField cuvTF;
   @FXML transient Button sendLetterTf;
    @FXML transient TextField letterTF;
//
    @FXML transient Button trimCuvBtn;
    @FXML transient TableView<dto> tabelFinal;
    @FXML transient TableColumn<dto, String> numeColf;
    @FXML transient TableColumn<dto, String> puncteFinal;
//    @FXML transient  Button sendWordBtn;

    public Controller() throws RemoteException {
    }

    public void setService(IService service) {
        this.service = service;
         tabelCuv.setItems(modelPlayes);
         tabelFinal.setItems(modelFinal);

        nameCol.setCellValueFactory(new PropertyValueFactory<dto, String>("jucName"));
        cuvCol.setCellValueFactory(new PropertyValueFactory<dto, String>("trans"));
        numeColf.setCellValueFactory(new PropertyValueFactory<dto, String>("jucName"));
        puncteFinal.setCellValueFactory(new PropertyValueFactory<dto, String>("points"));
//        letterBtn.setDisable(true);

    }
    public void setStage(Scene sc){
        this.myScene=sc;
    }

    public void setJucatorCurent(User jucatorCurent) {
        this.jucatorCurent = jucatorCurent;
        myJucatorTF.setText(jucatorCurent.getName());
        myJucatorTF.setEditable(false);
        puncteTf.setText(String.valueOf(0));
    }
    public void logOut(){
        service.logOut(jucatorCurent.name);
        logInController.primaryStage.setScene(myScene);
    }

    public void setLogInController(LogInController logInController){
        this.logInController=logInController;
    }

    public void startGame(MouseEvent event) {
        service.startGame(jucatorCurent.name,cuvTF.getText());
    }

    public void allPlayers(List<dto> players){
        Platform.runLater(()-> {
            trimCuvBtn.setDisable(true);
            modelPlayes.clear();
            modelPlayes.setAll( players.stream().filter(x->!x.jucName.equals(jucatorCurent.name)).collect(Collectors.toList()));
            puncteTf.setText(String.valueOf(players.stream().filter(x->x.jucName.equals(jucatorCurent.name)).findFirst().get().points));
        });

    }
    public void endGame(List<dto> players){
        Platform.runLater(()-> {
            trimCuvBtn.setDisable(true);
            modelPlayes.clear();
            modelFinal.setAll( players);
        });
    }

    public void sendletter(MouseEvent event) {
        String letter =  this.letterTF.getText().trim();
        this.letterTF.clear();
        String player="";
        if (tabelCuv.getSelectionModel().getSelectedItem()!=null)
            player = tabelCuv.getSelectionModel().getSelectedItem().jucName;
        service.sendLetter(jucatorCurent.name,letter,player);
    }
    /*
    public void finalJoc(int id) {
        Platform.runLater(() -> {
                    if (id == jucatorCurent.id) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle(jucatorCurent.nume);
                        alert.setContentText("Ai Castigat");
                        alert.showAndWait();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle(jucatorCurent.nume);
                        alert.setContentText("Ai Pierdut");
                        alert.showAndWait();
                    }
                }
        );
    }

     */
}
