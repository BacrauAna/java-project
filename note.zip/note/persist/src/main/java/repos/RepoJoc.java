package repos;

import domain.Joc;
import domain.Jucator;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class RepoJoc {
    SessionFactory sessionFactory;
    RepoJucatori repoJucatori;

    public RepoJoc() {
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            StandardServiceRegistryBuilder.destroy( registry );
        }
        repoJucatori=new RepoJucatori();
        repoJucatori.setSessionFactory(sessionFactory);
    }

    public RepoJoc(SessionFactory sessionFactory, RepoJucatori repoJucatori) {
        this.sessionFactory = sessionFactory;
        this.repoJucatori=repoJucatori;
    }

    public Joc save(Joc joc){
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.update(joc);
            tran.commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());

        }
        joc.jucatori.forEach(x->{
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.save(x);

            tran.commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }});
        joc.jucatori.forEach(x-> {
            x.runde.forEach(y -> {
                try (Session session1 = sessionFactory.openSession()) {
                    Transaction tran1 = session1.beginTransaction();
                    session1.save(y);
                    tran1.commit();
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
            });
        });
        return joc;
    }

    public Joc createNew() {
        Joc joc = new Joc();
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            session.save(joc);

            tran.commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());

        }
        return joc;
    }
    public Joc findOne(int idJoc){
        Joc joc=null;

        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            joc = session.createQuery("from domain.Joc as us where us.id = :n ", Joc.class)
                    .setInteger("n",idJoc)
                    .setMaxResults(1)
                    .uniqueResult();
            List<Jucator> jucators=new ArrayList<>();
            joc.jucatori.forEach(x->{
                Jucator jucator = repoJucatori.findOne(x.id);
                jucators.add(jucator);
            });
            joc.jucatori=jucators;
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return joc;
    }
}
