package repos;

import domain.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.context.annotation.Configuration;


public class RepoUsers {

    private SessionFactory sessionFactory;

    public RepoUsers(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public RepoUsers() {
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            StandardServiceRegistryBuilder.destroy( registry );
        }
    }

    public User findOne(String name, String pass){
        User user=null;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            user = session.createQuery("from domain.User as us where us.name = :n and us.pass= :p",User.class)
                    .setString("n",name)
                    .setString("p",pass)
                    .setMaxResults(1)
                    .uniqueResult();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return user;
    }
    public User findOne(String nume){
        User user=null;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            user = session.createQuery("from domain.User as us where us.name = :n ",User.class)
                    .setString("n",nume)
                    .setMaxResults(1)
                    .uniqueResult();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return user;
    }
}
