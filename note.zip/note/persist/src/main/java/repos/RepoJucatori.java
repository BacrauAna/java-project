package repos;

import domain.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class RepoJucatori {

    RepoUsers repoUsers;
    SessionFactory sessionFactory;

    public RepoJucatori() {
        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
                .configure() // configures settings from hibernate.cfg.xml
                .build();
        try {
            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
        }
        catch (Exception e) {
            StandardServiceRegistryBuilder.destroy( registry );
        }
           }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public RepoJucatori(SessionFactory sessionFactory,RepoUsers repoUsers) {
        this.sessionFactory = sessionFactory;
        this.repoUsers=repoUsers;
    }
    public Jucator findOne(int id){
        Jucator jucator=null;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            jucator = session.createQuery("from domain.Jucator as us where us.id = :n ",Jucator.class)
                    .setInteger("n",id)
                    .setMaxResults(1)
                    .uniqueResult();
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return jucator;
    }
    public List<jucatorDto> findSome(int idJoc){
        List<Jucator> list=new ArrayList<>();
        List<jucatorDto> list2=new ArrayList<>();
        Joc joc;
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            list = session.createQuery("FROM Jucator",Jucator.class).list();
            list.forEach(x->{
                if (x.joc.id==idJoc) {

                    list2.add(new jucatorDto(x.user.name, x.cuv, x.puncte));
                }
            });
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return list2;
    }
    public List<RundaDto> getRunda(int jucId) {
        List<Runda> list;
        List<RundaDto> rundaDtos=new ArrayList<>();
        try (Session session = sessionFactory.openSession()) {
            Transaction tran = session.beginTransaction();
            list = session.createQuery("FROM Runda j where j.jucator.id= :id", Runda.class)
                    .setInteger("id",jucId).list();
            list.forEach(x -> {
                rundaDtos.add(new RundaDto(x.nrRunda, x.puncte, x.prop));
            });
            tran.commit();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return rundaDtos;
    }
    public List<RundaDto> findSome2(int idJoc,String userName){
        List<RundaDto> list2=new ArrayList<>();
        try (Session session =  sessionFactory.openSession()){
            Transaction tran = session.beginTransaction();
            List<Jucator> list = session.createQuery("FROM Jucator j where j.joc.id= :id",Jucator.class)
                    .setInteger("id",idJoc).list();
            list.forEach(x->{
                if (x.user.name.equals(userName)) {
                    List<RundaDto> aux=getRunda(x.id);
                    aux.forEach(y->list2.add(y));
                }
            });
            tran.commit();
        }catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return list2;
    }
}
