package rest.control;

import domain.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import repos.RepoJoc;
import repos.RepoJucatori;
import repos.RepoUsers;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/cuvant")
public class MyRestController {

    @Autowired
    public RepoJucatori repoJucatori;
    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public String getHello(){
        return "hello";
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> getById (@PathVariable int id){
        int z;
        List<jucatorDto> juc=repoJucatori.findSome(id);
        if (juc==null)
            return new ResponseEntity<String>("User not found", HttpStatus.NOT_FOUND);
        else {
            return new ResponseEntity<List<jucatorDto>>(juc, HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/{idJoc}/{user}", method = RequestMethod.GET)
    public ResponseEntity<?> geRunde (@PathVariable int idJoc, @PathVariable String user){
        int z;
        List<RundaDto> rundaDtos=repoJucatori.findSome2(idJoc,user);
        if (rundaDtos==null)
            return new ResponseEntity<String>("User not found", HttpStatus.NOT_FOUND);
        else {
            return new ResponseEntity<List<RundaDto>>(rundaDtos, HttpStatus.OK);
        }
    }
}

