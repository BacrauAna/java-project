package rest;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Primary;

@ComponentScan("repos")
@ComponentScan("rest.control")
@ImportResource("spring.xml")
@SpringBootApplication
public class SartRest{
//  ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");

    public static void main(String[] args) {
//        ApplicationContext factory = new ClassPathXmlApplicationContext("classpath:spring.xml");

        SpringApplication.run(SartRest.class, args);
    }
//    @Primary
//    @Bean
//    public SessionFactory sessionFactory(){
//        SessionFactory sessionFactory=null;
//        final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
//                .configure() // configures settings from hibernate.cfg.xml
//                .build();
//        try {
//            sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
//        }
//        catch (Exception e) {
//            StandardServiceRegistryBuilder.destroy( registry );
//        }
//        return sessionFactory;
//    }

}
