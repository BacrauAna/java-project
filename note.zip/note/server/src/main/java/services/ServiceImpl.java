package services;

import domain.*;
import interfaces.IObserver;
import interfaces.IService;
import repos.RepoJoc;
import repos.RepoJucatori;
import repos.RepoUsers;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

public class ServiceImpl implements IService {
    public RepoUsers repoUsers;
    public RepoJucatori repoJucatori;
    public RepoJoc repoJoc;
    public Joc currentGame;
    public int nrRunda;
    public Map<String,IObserver> nameMap = new ConcurrentHashMap<>();
    public Map<String, Jucator> jucatorMap=new ConcurrentHashMap<>();
    public String letters="abcdefghijklmnopqrstuvwxyz";

    public ServiceImpl(RepoUsers repoUsers, RepoJucatori repoJucatori, RepoJoc repoJoc) {
        this.repoUsers = repoUsers;
        this.repoJucatori=repoJucatori;
        this.repoJoc=repoJoc;
        this.currentGame=repoJoc.createNew();
    }

    @Override
    public User logIn(String name, String pass, IObserver obs) {
        User user = repoUsers.findOne(name,pass);
        nameMap.put(user.getName(),obs);
        return user;
    }

    public String getString(String s){
        String a="";
        if (s.indexOf('!')!=-1)
            return s.substring(0, s.length()-1);
        for(int i=0; i<s.length(); i++)
            if (this.letters.indexOf(s.charAt(i))!=-1)
                a+="_ ";
            else a+=s.charAt(i)+" ";
        return a;
    }

    @Override
    public void startGame(String name, String cuvant) {
        User user=repoUsers.findOne(name);
        Jucator jucator=new Jucator(currentGame,user,cuvant,0);
        currentGame.jucatori.add(jucator);
        jucatorMap.put(name,jucator);
        List<dto> list=new ArrayList<>();
        jucatorMap.values().forEach(x->{
            list.add(new dto(x.user.name, x.cuv, this.getString(x.cuv),0));
        });
        if (jucatorMap.size()==nameMap.size()){
            nrRunda=0;
            ExecutorService executorService= Executors.newFixedThreadPool(10);
            nameMap.values().forEach(x -> {
                executorService.execute(()-> {
                    try {
                        x.allPlayers(list);
                    }catch (RemoteException ex){
                        ex.printStackTrace();
                    }
                });
            });
        }
    }
    public void retrimite(){
        List<dto> list=new ArrayList<>();
        jucatorMap.values().forEach(x->{
            list.add(new dto(x.user.name, x.cuv, this.getString(x.cuv),x.puncte));
        });


        if (jucatorMap.size()==nameMap.size()){
            ExecutorService executorService= Executors.newFixedThreadPool(10);
            nameMap.values().forEach(x -> {
                executorService.execute(()-> {
                    try {
                        x.allPlayers(list);
                    }catch (RemoteException ex){
                        ex.printStackTrace();
                    }
                });
            });
        }

    }

    public void sendLetter(String sender,String letter, String player){
        nrRunda++;
        AtomicReference<Integer> p = new AtomicReference<>(0);
        String s="";
        if (player.length()==0) {
            jucatorMap.forEach((x, y) -> {
                if (!x.equals(sender)) {
                    for (int i = 0; i < y.cuv.length(); i++)
                        if (y.cuv.charAt(i) == letter.charAt(0))
                            p.getAndSet(p.get() + 1);
                }
            });
            this.letters=letters.replace(letter.charAt(0),'1');
        }
        else {
            if (jucatorMap.get(player).cuv.equals(letter)){
                p.getAndSet(10);
                jucatorMap.get(player).cuv+="!";
            }
        }
        jucatorMap.get(sender).puncte+=p.get();
        Runda r=new Runda(0,jucatorMap.get(sender),p.get(),letter,nrRunda/jucatorMap.size());
        jucatorMap.get(sender).runde.add(r);
        if (nrRunda<jucatorMap.size()*2)
            retrimite();
        else
            endGame();
    }
    public void endGame(){
        currentGame.jucatori=jucatorMap.values().stream().collect(Collectors.toList());
        repoJoc.save(currentGame);
        List<dto> list=new ArrayList<>();
        jucatorMap.values().forEach(x->{
            list.add(new dto(x.user.name, x.cuv, this.getString(x.cuv),x.puncte));
        });
        if (jucatorMap.size()==nameMap.size()){
            ExecutorService executorService= Executors.newFixedThreadPool(10);
            nameMap.values().forEach(x -> {
                executorService.execute(()-> {
                    try {
                        x.endGame(list);
                    }catch (RemoteException ex){
                        ex.printStackTrace();
                    }
                });
            });
        }

    }

    @Override
    public void logOut(String name) {
        this.nameMap.remove(name);
    }
}
